import csv
import json
import os
from tkinter import *
from tkinter import filedialog
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime

def sanitize_text(text):
    return ''.join(e for e in text if e.isalnum())


def create_card_image(text, img_filename):
    width, height = 700, 400
    background_color = (255, 255, 255)  # White
    text_color = (0, 0, 0)  # Black
    font_size = 14

    image = Image.new('RGB', (width, height), color=background_color)
    draw = ImageDraw.Draw(image)

    font = ImageFont.truetype("Helvetica-Bold.ttf", font_size)

    # Define the right margin as 90% of the width
    right_margin = int(width * 0.9)

    # Split the text into rows
    rows = text.split("\n")

    # Initialize the wrapped text
    wrapped_text = ""

    for row in rows:
        # Split the row into words
        words = row.split()
        row_text = ""

        for word in words:
            test_text = row_text + word + " "
            test_width, _ = draw.textsize(test_text, font=font)
            if test_width > right_margin:
                # If the test text exceeds the right margin, add a line break
                wrapped_text += row_text + "\n"
                row_text = ""
            row_text += word + " "

        wrapped_text += row_text + "\n"

    # Calculate the position for centering the wrapped text
    wrapped_text_width, wrapped_text_height = draw.textsize(wrapped_text, font=font)
    x = (width - wrapped_text_width) // 2
    y = (height - wrapped_text_height) // 2

    # Draw the wrapped text on the image
    draw.text((x, y), wrapped_text, font=font, fill=text_color)
    image.save(img_filename)

def convert_to_json(csv_file):
    data = []
    
    with open(csv_file, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            entry = {
                "id": sanitize_text(row["Timestamp"]),
                "Email": row["Email Address"],
                "Name": row["Name"],
                "Company": row["Company"],
                "Phone": row["Phone"],
                "Contact Method": row["Best way to get in Contact"],
                "tags": [tag.strip() for tag in row["Skill / Trade"].split(',')],
                "url": row["Portfolio Link or Website Link"],
                "Time Zone": row["Time Zone"],
                "Share Data": ["Yes"] if row["Agreed to Share this Data with others."] == "Yes" else ["No"]
            }

            data.append(entry)
            
            # Business Card Front
            front_img_filename = f"{sanitize_text(row['Timestamp'])}-Side-A.jpg"
            if not os.path.isfile(front_img_filename):
                card_data = f"Name: {row['Name']}, Company: {row['Company']}, Phone: {row['Phone']}, Email: {row['Email Address']}, Portfolio: {row['Portfolio Link or Website Link']}, Best way to get in Touch: {row['Best way to get in Contact']}, My Time Zone: {row['Time Zone']}, My Skills: {row['Skill / Trade']}"
                card_img = Image.new('RGB', (1, 1), color=(73, 109, 137))
                card_img.save(front_img_filename)

            # Business Card Back
            back_img_filename = f"{sanitize_text(row['Timestamp'])}-Side-B.jpg"
            if not os.path.isfile(back_img_filename):
                card_data = row['Company']
                card_img = Image.new('RGB', (1, 1), color=(73, 109, 137))
                card_img.save(back_img_filename)

    return data

def browse_csv():
    global csv_file_path
    csv_file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    if csv_file_path:
        btn_convert.config(state=NORMAL)

def get_image_filename(entry_id, side):
    folder_path, _ = os.path.split(csv_file_path)
    images_folder = os.path.join(folder_path, f"Images-{datetime.now().strftime('%Y%m%d')}")
    os.makedirs(images_folder, exist_ok=True)
    img_filename = os.path.join(images_folder, f"{sanitize_text(entry_id)}-Side-{side}.jpg")
    return img_filename

def convert_csv_to_json():
    if not csv_file_path:
        return

    json_data = convert_to_json(csv_file_path)

    for entry in json_data:
        # Business Card Front
        front_img_filename = get_image_filename(entry['id'], 'A')
        if not os.path.isfile(front_img_filename):
            create_card_image(
                text=f"Name: {entry['Name']}\nCompany: {entry['Company']}\nPhone: {entry['Phone']}\nEmail: {entry['Email']}\nWebsite: {entry['url']}\nBest way to get in Touch: {entry['Contact Method']}\nMy Time Zone: {entry['Time Zone']}\nMy Skills: {', '.join(entry['tags'])}",
                img_filename=front_img_filename
            )

        # Business Card Back
        back_img_filename = get_image_filename(entry['id'], 'B')
        if not os.path.isfile(back_img_filename):
            create_card_image(
                text=entry['Company'],
                img_filename=back_img_filename
            )

    output_file = os.path.join(folder_path, f"cards-{datetime.now().strftime('%Y%m%d%H%M%S')}.json")
    with open(output_file, "w") as jsonfile:
        json.dump(json_data, jsonfile, indent=2)

    lbl_status.config(text=f"Conversion completed successfully. JSON file saved as {output_file}")

if __name__ == "__main__":
    root = Tk()
    root.title("CSV to JSON Converter")

    csv_file_path = None

    lbl_instruction = Label(root, text="Select a CSV file to convert:")
    lbl_instruction.pack(pady=10)

    btn_browse = Button(root, text="Browse", command=browse_csv)
    btn_browse.pack(pady=5)

    btn_convert = Button(root, text="Convert to JSON", command=convert_csv_to_json, state=DISABLED)
    btn_convert.pack(pady=5)

    lbl_status = Label(root, text="", fg="green")
    lbl_status.pack(pady=10)

    root.mainloop()
